import { supabase } from "@/integrations/supabase/client";

const getFileExtension = (fileName: string) => {
  const segments = fileName.split(".");
  return segments.length > 1 ? segments.pop()?.toLowerCase() || "bin" : "bin";
};

export const uploadBrandingAsset = async (file: File, folder: string) => {
  const fileExt = getFileExtension(file.name);
  const filePath = `${folder}/${crypto.randomUUID()}.${fileExt}`;

  const { error } = await supabase.storage.from("branding").upload(filePath, file, {
    cacheControl: "3600",
    upsert: false,
  });

  if (error) throw error;

  return filePath;
};
