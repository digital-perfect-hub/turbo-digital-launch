import { motion } from "framer-motion";
import { ArrowUpRight, LayoutTemplate, ShieldCheck, Sparkles } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { defaultSiteText, useSiteSettings } from "@/hooks/useSiteSettings";
import { buildRenderImageUrl } from "@/lib/image";

type PortfolioItem = {
  id: string;
  title: string | null;
  description: string | null;
  image_url: string | null;
  url: string | null;
  tags: string[] | null;
};

const fallbackPortfolioItems: PortfolioItem[] = [
  {
    id: "fallback-portfolio-1",
    title: "SEO-Landingpage mit klarer Conversion-Hierarchie",
    description:
      "Premium-Light Layout mit lesbaren Headlines, sauberer Informationsarchitektur und einer CTA-Führung, die direkt auf Anfragen ausgerichtet ist.",
    image_url: null,
    url: null,
    tags: ["Landingpage", "SEO", "Conversion"],
  },
  {
    id: "fallback-portfolio-2",
    title: "Onlineshop-Struktur für verkaufsstarke Nutzerwege",
    description:
      "Ein robuster Shop-Auftritt mit klarer Produktnavigation, Vertrauenssignalen und einer visuellen Sprache, die auch ohne echte Referenzbilder professionell wirkt.",
    image_url: null,
    url: null,
    tags: ["Shop", "UX", "Performance"],
  },
  {
    id: "fallback-portfolio-3",
    title: "Unternehmenswebsite mit technischer SEO-Basis",
    description:
      "Strukturierte Inhaltsblöcke, starke Lesbarkeit und ein stabiles Portfolio-Modul, das nicht zusammenfällt, wenn der Admin noch nichts gepflegt hat.",
    image_url: null,
    url: null,
    tags: ["Unternehmensseite", "Tech SEO", "Premium UI"],
  },
];

const placeholderTiles = [
  { title: "Struktur", text: "Klare Inhaltslogik statt Leerraum-Chaos.", icon: LayoutTemplate },
  { title: "Vertrauen", text: "Premium-Look mit ruhiger Informationsführung.", icon: ShieldCheck },
  { title: "Wirkung", text: "Sichtbare Qualität auch ohne echtes Referenzbild.", icon: Sparkles },
];

const PortfolioSection = () => {
  const { getSetting } = useSiteSettings();

  const { data: portfolioItems = [], isLoading } = useQuery({
    queryKey: ["portfolio_items"],
    queryFn: async (): Promise<PortfolioItem[]> => {
      const { data, error } = await supabase
        .from("portfolio_items")
        .select("id, title, description, image_url, url, tags")
        .eq("is_visible", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return (data as PortfolioItem[]) ?? [];
    },
  });

  const effectiveItems = portfolioItems.length > 0 ? portfolioItems : fallbackPortfolioItems;

  return (
    <section id="portfolio" className="bg-surface py-24 sm:py-28 md:py-32" aria-label="Portfolio">
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.55 }}
          className="mb-14 max-w-4xl"
        >
          <p className="section-label">{getSetting("home_portfolio_kicker", defaultSiteText.home_portfolio_kicker)}</p>
          <h2 className="section-title">{getSetting("home_portfolio_title", defaultSiteText.home_portfolio_title)}</h2>
        </motion.div>

        <div className="grid gap-5 xl:grid-cols-3">
          {effectiveItems.map((item, index) => {
            const hasImage = Boolean(item.image_url);
            const imageSrc = hasImage ? buildRenderImageUrl(item.image_url, { width: 1200, quality: 84 }) : "";

            return (
              <motion.article
                key={item.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className={`premium-card overflow-hidden ${isLoading ? "premium-skeleton" : ""}`}
              >
                <div className="relative z-10">
                  {hasImage ? (
                    <div className="relative h-[250px] overflow-hidden border-b border-slate-200/70 bg-slate-100">
                      <img src={imageSrc} alt={item.title || "Projekt"} className="h-full w-full object-cover" loading="lazy" />
                      <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_10%,rgba(15,23,42,0.45)_100%)]" />
                    </div>
                  ) : (
                    <div className="grid gap-3 border-b border-slate-200/70 bg-[radial-gradient(circle_at_top_left,rgba(255,75,44,0.14),transparent_26%),linear-gradient(180deg,#ffffff,#f8fafc)] p-5 sm:grid-cols-3">
                      {placeholderTiles.map((tile) => {
                        const Icon = tile.icon;
                        return (
                          <div key={tile.title} className="rounded-[1.3rem] border border-white bg-white/85 p-4 shadow-[0_20px_40px_-32px_rgba(15,23,42,0.22)]">
                            <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-white">
                              <Icon size={18} />
                            </div>
                            <p className="text-sm font-bold text-slate-900">{tile.title}</p>
                            <p className="mt-2 text-xs leading-relaxed text-slate-600">{tile.text}</p>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="p-6 md:p-7">
                    <div className="mb-4 flex items-center justify-between gap-3">
                      <span className="premium-pill">Case {String(index + 1).padStart(2, "0")}</span>
                      {item.url ? (
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-700 transition-all duration-300 hover:border-slate-300 hover:text-slate-900"
                          aria-label={`Projekt ${item.title || "öffnen"}`}
                        >
                          <ArrowUpRight size={16} />
                        </a>
                      ) : null}
                    </div>

                    <h3 className="text-xl font-bold leading-tight text-slate-900">{item.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-slate-600">{item.description}</p>

                    <div className="mt-5 flex flex-wrap gap-2">
                      {(item.tags && item.tags.length > 0 ? item.tags : ["Premium UI", "SEO", "Performance"]).map((tag) => (
                        <span key={tag} className="premium-pill">{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
