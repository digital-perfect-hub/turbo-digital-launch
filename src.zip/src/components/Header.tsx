import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, ChevronDown } from "lucide-react";
import { useGlobalTheme } from "@/hooks/useGlobalTheme";
import { useSiteContext } from "@/context/SiteContext";
import { DEFAULT_SITE_ID } from "@/lib/site";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

type NavLink = {
  id: string;
  label: string;
  url: string;
  parent_id: string | null;
  sort_order: number;
};

type HeaderProps = {
  forceSolid?: boolean;
  solidBackgroundClassName?: string;
  navigation?: NavLink[];
  contactCta?: string;
};

const cleanNavCtaLabel = (value: unknown) => {
  const raw = typeof value === "string" ? value.trim().replace(/\s+/g, " ") : "";
  if (!raw) return "Anfrage starten";

  // Harter Schutz gegen den aktuellen Datenbankfehler aus navigation_theme.cta_label.
  if (/^Anfrage starten\d+$/i.test(raw)) return "Anfrage starten";

  return raw;
};

const cleanNavCtaLink = (value: unknown) => {
  const raw = typeof value === "string" ? value.trim() : "";
  return raw || "#kontakt";
};

const Header = ({ forceSolid = false, solidBackgroundClassName, navigation, contactCta }: HeaderProps) => {
  const { activeSiteId } = useSiteContext();
  const siteId = activeSiteId || DEFAULT_SITE_ID;
  const headerRef = useRef<HTMLElement | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOffset, setMobileMenuOffset] = useState(0);
  const [openMobileDropdowns, setOpenMobileDropdowns] = useState<Record<string, boolean>>({});

  const { logoUrl, settings } = useGlobalTheme();

  const { data: links = [] } = useQuery({
    queryKey: ["navigation_links_frontend", siteId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("navigation_links")
        .select("*")
        .eq("site_id", siteId)
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as NavLink[];
    },
  });

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 14);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const overflow = isMobileOpen ? "hidden" : "";
    document.body.style.overflow = overflow;
    document.documentElement.style.overflow = overflow;

    if (!isMobileOpen) {
      setOpenMobileDropdowns({});
    }

    return () => {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
    };
  }, [isMobileOpen]);

  useEffect(() => {
    const closeOnDesktop = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileOpen(false);
      }
    };

    window.addEventListener("resize", closeOnDesktop);
    return () => window.removeEventListener("resize", closeOnDesktop);
  }, []);

  useEffect(() => {
    const updateOffset = () => {
      setMobileMenuOffset(headerRef.current?.offsetHeight ?? 0);
    };

    updateOffset();

    const resizeObserver = typeof ResizeObserver !== "undefined"
      ? new ResizeObserver(() => updateOffset())
      : null;

    if (headerRef.current && resizeObserver) {
      resizeObserver.observe(headerRef.current);
    }

    window.addEventListener("resize", updateOffset);

    return () => {
      resizeObserver?.disconnect();
      window.removeEventListener("resize", updateOffset);
    };
  }, []);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      setMobileMenuOffset(headerRef.current?.offsetHeight ?? 0);
    });

    return () => window.cancelAnimationFrame(frame);
  }, [isScrolled, isMobileOpen, forceSolid]);

  const brandName = useMemo(() => settings.company_name || "Digital-Perfect", [settings.company_name]);
  const logoFontClass = settings.logo_font_family === "serif" ? "font-serif" : settings.logo_font_family === "mono" ? "font-mono" : "";
  const navFontFamily = settings.nav_font_family === "serif" ? "font-serif" : settings.nav_font_family === "mono" ? "font-mono" : "font-sans";
  const navFontWeight = settings.nav_font_weight === "normal" ? "font-normal" : settings.nav_font_weight === "medium" ? "font-medium" : settings.nav_font_weight === "extrabold" ? "font-extrabold" : "font-bold";
  const navFontStyle = settings.nav_font_style === "italic" ? "italic" : "not-italic";
  const navTypographyClasses = `${navFontFamily} ${navFontWeight} ${navFontStyle}`;

  const scrollToHomeAnchor = (hash: string) => {
    const targetId = decodeURIComponent(hash.replace(/^#/, ""));
    if (!targetId) return false;

    const target = document.getElementById(targetId);
    if (!target) return false;

    target.scrollIntoView({ behavior: "smooth", block: "start" });

    if (window.location.hash !== hash) {
      window.history.pushState(null, "", hash);
    }

    return true;
  };

  const handleLinkClick = (url: string) => {
    const rawUrl = url.trim();
    const homeHash = rawUrl.startsWith("/#")
      ? rawUrl.slice(1)
      : rawUrl.startsWith("#")
        ? rawUrl
        : null;

    if (homeHash) {
      if (location.pathname === "/") {
        scrollToHomeAnchor(homeHash);
      } else {
        navigate({ pathname: "/", hash: homeHash });
      }

      setIsMobileOpen(false);
      return;
    }

    window.location.href = rawUrl;
    setIsMobileOpen(false);
  };

  const toggleMobileDropdown = (id: string) => {
    setOpenMobileDropdowns((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const effectiveLinks = navigation ?? links;
  const topLevelLinks = effectiveLinks.filter((l) => !l.parent_id);
  const getChildren = (parentId: string) => effectiveLinks.filter((l) => l.parent_id === parentId);

  const desktopNavColor = forceSolid ? "var(--hero-headline)" : "var(--nav-text, var(--surface-page-foreground))";
  const desktopNavHoverColor = forceSolid ? "var(--theme-primary-hex)" : "var(--nav-hover-text, var(--theme-primary-hex))";
  const dropdownShellClass = forceSolid ? "header-dropdown-shell" : "shadow-xl";
  const dropdownShellStyle = forceSolid ? undefined : { background: "var(--nav-bg)", borderColor: "var(--nav-border)", backdropFilter: "blur(20px)" };
  const dropdownHoverBg = forceSolid ? "color-mix(in srgb, var(--hero-headline) 8%, transparent)" : "var(--nav-hover-bg, rgba(255,75,44,0.05))";
  const useSolidMobileShell = forceSolid || isMobileOpen;
  const mobileOverlayClass = "header-mobile-shell";
  const mobileTextClass = useSolidMobileShell ? "header-solid-text" : "text-foreground";
  const mobileMutedClass = useSolidMobileShell ? "header-solid-muted" : "text-muted-foreground hover:text-primary";
  const mobileBorderClass = useSolidMobileShell ? "header-solid-border" : "border-border/50";
  const mobileIconClass = useSolidMobileShell ? "header-solid-icon" : "text-primary";
  const mobileOverlayStyle = {
    top: mobileMenuOffset,
    height: mobileMenuOffset ? `calc(100dvh - ${mobileMenuOffset}px)` : "100dvh",
    overscrollBehavior: "contain" as const,
  };
  const logoColor = forceSolid ? "var(--hero-headline)" : settings.text_logo_color_hex || desktopNavColor;
  const navigationThemeSettings = ((settings.navigation_theme && typeof settings.navigation_theme === "object" && !Array.isArray(settings.navigation_theme))
    ? (settings.navigation_theme as Record<string, unknown>)
    : {}) as Record<string, unknown>;
  const navCtaLabel = contactCta ?? cleanNavCtaLabel(navigationThemeSettings.cta_label);
  const navCtaLink = contactCta ? "#kontakt" : cleanNavCtaLink(navigationThemeSettings.cta_link);
  // Header ist bewusst immer solide/hell (statt transparent über dem Hero und erst
  // nach dem Scrollen solide) - fixe Sichtbarkeit und Kontrast unabhängig vom Scroll-Stand.
  const headerClassName = forceSolid || isMobileOpen
    ? `py-4 header-solid-shell border-b ${solidBackgroundClassName || ""}`
    : `py-4 border-b ${isScrolled ? "shadow-lg" : "shadow-sm"}`;
  const headerStyle = forceSolid || isMobileOpen
    ? undefined
    : { background: "var(--nav-bg)", borderColor: "var(--nav-border)", backdropFilter: "blur(20px)" };

  return (
    <header ref={headerRef} className={`fixed left-0 right-0 top-0 z-50 transition-all duration-500 ${headerClassName}`} style={headerStyle}>
      <div className="section-container">
        <div className="flex items-center justify-between">
          <a href="/" className="relative z-10 flex items-center gap-3 group outline-none" onClick={() => setIsMobileOpen(false)}>
            {!settings.use_text_logo && logoUrl ? (
              <img src={logoUrl} alt={brandName} className="h-9 w-auto object-contain transition-transform duration-300 group-hover:scale-105" />
            ) : (
              <span className={`text-2xl font-black tracking-tighter transition-opacity hover:opacity-80 ${logoFontClass}`} style={{ color: logoColor }}>
                {brandName}
                {settings.show_logo_dot !== false && (
                  <span style={{ color: settings.logo_dot_color_hex || settings.primary_color_hex || "var(--theme-primary-hex)" }}>.</span>
                )}
              </span>
            )}
          </a>

          <nav className="hidden lg:flex items-center gap-8">
            {topLevelLinks.map((item) => {
              const children = getChildren(item.id);
              const hasChildren = children.length > 0;

              return (
                <div key={item.id} className="relative group flex items-center">
                  <button
                    onClick={() => !hasChildren ? handleLinkClick(item.url) : null}
                    className={`relative flex items-center gap-1.5 py-1 text-[15px] 2xl:text-base uppercase tracking-[0.12em] outline-none transition-colors duration-300 ${navTypographyClasses}`}
                    style={{ color: desktopNavColor }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = desktopNavHoverColor)}
                    onMouseLeave={(e) => (e.currentTarget.style.color = desktopNavColor)}
                  >
                    {item.label}
                    {hasChildren && <ChevronDown size={14} className="transition-transform group-hover:rotate-180" />}

                    {settings.nav_show_underline && (
                      <span
                        className={`absolute -bottom-1 left-0 h-[2px] w-full ${
                          settings.nav_animate_underline
                            ? "origin-left scale-x-0 transition-transform duration-300 ease-out group-hover:scale-x-100"
                            : "opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                        }`}
                        style={{ backgroundColor: forceSolid ? "var(--theme-primary-hex)" : "var(--nav-underline, var(--theme-primary-hex))" }}
                      />
                    )}
                  </button>

                  {hasChildren && (
                    <div className="absolute left-0 top-full min-w-[200px] translate-y-2 pt-4 opacity-0 invisible transition-all duration-300 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                      <div className={`flex flex-col gap-1 rounded-2xl border p-2 ${dropdownShellClass}`} style={dropdownShellStyle}>
                        {children.map((child) => (
                          <button
                            key={child.id}
                            onClick={() => handleLinkClick(child.url)}
                            className={`rounded-xl px-4 py-2.5 text-left text-sm transition-colors duration-300 ${navTypographyClasses}`}
                            style={{ color: desktopNavColor }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.color = desktopNavHoverColor;
                              e.currentTarget.style.backgroundColor = dropdownHoverBg;
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.color = desktopNavColor;
                              e.currentTarget.style.backgroundColor = "transparent";
                            }}
                          >
                            {child.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {navCtaLabel ? (
              <button
                onClick={() => handleLinkClick(navCtaLink)}
                className={forceSolid ? "btn-primary !px-7 !py-3.5 text-[15px] 2xl:text-base shadow-[0_10px_20px_-10px_rgba(var(--primary),0.3)] transition-colors" : "nav-cta-button inline-flex items-center justify-center rounded-full px-7 py-3.5 text-[15px] 2xl:text-base font-bold shadow-lg transition-all duration-300 hover:-translate-y-0.5"}
              >
                {navCtaLabel}
              </button>
            ) : null}
          </nav>

          <button
            className={`relative z-10 p-2 outline-none lg:hidden ${useSolidMobileShell ? "header-solid-text" : ""}`}
            style={useSolidMobileShell ? undefined : { color: desktopNavColor }}
            onClick={() => setIsMobileOpen((prev) => !prev)}
            aria-label={isMobileOpen ? "Menü schließen" : "Menü öffnen"}
          >
            {isMobileOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 24 }}
            transition={{ duration: 0.24, ease: "easeOut" }}
            className={`fixed inset-x-0 bottom-0 z-40 border-t shadow-2xl lg:hidden ${mobileOverlayClass}`}
            style={mobileOverlayStyle}
          >
            <nav className="flex h-full flex-col px-6 pb-8 pt-6">
              <div className="flex-1 overflow-y-auto pr-1">
                <div className="flex flex-col gap-4 pb-2">
                  {topLevelLinks.map((item) => {
                    const children = getChildren(item.id);
                    const hasChildren = children.length > 0;
                    const isOpen = openMobileDropdowns[item.id];

                    return (
                      <div key={item.id} className={`flex flex-col border-b pb-4 ${mobileBorderClass}`}>
                        <div className="flex items-center justify-between gap-3">
                          <button
                            onClick={() => !hasChildren ? handleLinkClick(item.url) : toggleMobileDropdown(item.id)}
                            className={`flex-1 text-left text-lg outline-none transition-colors ${mobileTextClass} ${navTypographyClasses}`}
                          >
                            {item.label}
                          </button>
                          {hasChildren && (
                            <button onClick={() => toggleMobileDropdown(item.id)} className={`shrink-0 p-2 ${mobileIconClass}`}>
                              <ChevronDown size={20} className={`transition-transform ${isOpen ? "rotate-180" : ""}`} />
                            </button>
                          )}
                        </div>

                        {hasChildren && isOpen && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2, ease: "easeOut" }}
                            className={`mt-4 flex flex-col gap-3 pl-4 ${mobileBorderClass} border-l-2`}
                          >
                            {children.map((child) => (
                              <button
                                key={child.id}
                                onClick={() => handleLinkClick(child.url)}
                                className={`text-left text-base outline-none transition-colors ${mobileMutedClass} ${navTypographyClasses}`}
                              >
                                {child.label}
                              </button>
                            ))}
                          </motion.div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {navCtaLabel ? (
                <button
                  onClick={() => handleLinkClick(navCtaLink)}
                  className={forceSolid ? "btn-primary mt-6 w-full !py-4 text-lg shadow-xl" : "nav-cta-button mt-6 inline-flex w-full items-center justify-center rounded-full px-6 py-4 text-lg font-bold shadow-xl transition-all duration-300 hover:-translate-y-0.5"}
                >
                  {navCtaLabel}
                </button>
              ) : null}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
