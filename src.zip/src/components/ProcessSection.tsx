import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";
import { defaultProcessSteps, defaultSiteText, type ProcessStep, useSiteSettings } from "@/hooks/useSiteSettings";
import { resolveHomepageSectionPatternClassFromSettings, resolveHomepageSectionStyleVarsFromSettings } from "@/lib/homepage-section-styles";

const processVisuals = [
  {
    src: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=900&q=82",
    alt: "Person füllt ein Kontaktformular am Laptop aus",
  },
  {
    src: "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=82",
    alt: "Kostenloser Kennenlern-Call mit Beratungsgespräch",
  },
  {
    src: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=82",
    alt: "Strategie und Angebot mit klarer Projektplanung",
  },
  {
    src: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=82",
    alt: "Umsetzung und Optimierung einer Website mit Performance-Daten",
  },
];

const navigateToTarget = (target: string) => {
  const normalized = (target || "").trim();
  if (!normalized) return;
  if (normalized.startsWith("#")) {
    document.querySelector(normalized)?.scrollIntoView({ behavior: "smooth" });
    return;
  }
  window.location.href = normalized;
};

const normalizeSteps = (steps: ProcessStep[]) =>
  steps.filter((step) => step?.step?.trim() && step?.title?.trim() && step?.description?.trim());

const ProcessSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const { getSetting, getJsonSetting, settings } = useSiteSettings();
  const sectionStyleVars = resolveHomepageSectionStyleVarsFromSettings(settings, "process");
  const sectionPatternClass = resolveHomepageSectionPatternClassFromSettings(settings, "process");

  const steps = normalizeSteps(getJsonSetting<ProcessStep[]>("home_process_steps", defaultProcessSteps));
  const kicker =
    getSetting("home_process_kicker", defaultSiteText.home_process_kicker).trim() || defaultSiteText.home_process_kicker;
  const title =
    getSetting("home_process_title", defaultSiteText.home_process_title).trim() || defaultSiteText.home_process_title;
  const ctaText =
    getSetting("home_process_cta_text", defaultSiteText.home_process_cta_text).trim() ||
    defaultSiteText.home_process_cta_text;
  const ctaLink =
    getSetting("home_process_cta_link", defaultSiteText.home_process_cta_link).trim() ||
    defaultSiteText.home_process_cta_link;

  return (
    <section id="ablauf" className={`homepage-style-scope dark-section ${sectionPatternClass} relative overflow-hidden py-24 md:py-32`} ref={ref} style={sectionStyleVars}>
      <div className="noise-overlay pointer-events-none absolute inset-0 z-0 opacity-20" />

      <div className="section-container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16 max-w-3xl md:mb-20"
        >
          <div
            className="mb-4 inline-flex max-w-max items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-[0.24em]"
            style={{
              background: "var(--button-primary-bg)",
              color: "var(--button-primary-text)",
              border: "1px solid color-mix(in srgb, var(--button-primary-bg) 72%, black 28%)",
              boxShadow:
                "0 18px 42px -26px color-mix(in srgb, var(--button-primary-bg) 72%, transparent)",
            }}
          >
            <span aria-hidden="true" className="text-sm leading-none">
              🚧
            </span>
            <span>{kicker}</span>
          </div>
          <h2 className="section-title mt-4 max-w-4xl">{title}</h2>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2 lg:gap-8 xl:grid-cols-4">
          {steps.map((step, index) => {
            const visual = processVisuals[index] || processVisuals[processVisuals.length - 1];

            return (
              <motion.div
                key={`${step.step}-${index}`}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] border p-0 transition-all duration-500 hover:shadow-xl glass-card"
              >
                <div className="relative h-44 overflow-hidden sm:h-48">
                  <img
                    src={visual.src}
                    alt={visual.alt}
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-[#0a1842]/35" />
                  {step.time ? (
                    <span className="dark-panel-kicker absolute bottom-5 left-5 inline-flex rounded-full border px-4 py-1.5 text-xs font-semibold uppercase tracking-wider backdrop-blur-md">
                      {step.time}
                    </span>
                  ) : null}
                </div>

                <div className="relative z-10 flex flex-1 flex-col p-8 sm:p-10">
                  <h3 className="hero-stat-value mb-4 text-2xl font-bold leading-tight">{step.title}</h3>
                  <p className="hero-stat-label flex-1 text-base leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 text-center"
        >
          <button
            onClick={() => navigateToTarget(ctaLink)}
            className="btn-primary !px-8 !py-4 text-base shadow-[0_0_40px_-10px_rgba(255,75,44,0.4)]"
          >
            {ctaText}
            <ArrowRight size={18} />
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default ProcessSection;
